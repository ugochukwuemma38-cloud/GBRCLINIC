
const openMenu = document.getElementById("openMenu");
const closeMenu = document.getElementById("closeMenu");
const menuScreen = document.getElementById("menuScreen");

openMenu.addEventListener("click", function () {
  menuScreen.classList.add("open");
  openMenu.setAttribute("aria-expanded", "true");
  closeMenu.focus();
});

function hideMenu() {
  menuScreen.classList.remove("open");
  openMenu.setAttribute("aria-expanded", "false");
  openMenu.focus();
}

closeMenu.addEventListener("click", hideMenu);

menuScreen.querySelectorAll("a").forEach(function (link) {
  link.addEventListener("click", hideMenu);
});

document.addEventListener("keydown", function (event) {
  if (event.key === "Escape" &&
      menuScreen.classList.contains("open")) {
    hideMenu();
  }
});


/* SERVICES CAROUSEL */
const servicesCarousel = document.getElementById("servicesCarousel");
const servicesPrev = document.getElementById("servicesPrev");
const servicesNext = document.getElementById("servicesNext");

servicesNext.addEventListener("click", function () {
  const cardWidth = servicesCarousel.clientWidth;
  const gap = 0;

  servicesCarousel.scrollBy({
    left: cardWidth + gap,
    behavior: "auto"
  });
});

servicesPrev.addEventListener("click", function () {
  const cardWidth = servicesCarousel.clientWidth;
  const gap = 0;

  servicesCarousel.scrollBy({
    left: -(cardWidth + gap),
    behavior: "auto"
  });
});
